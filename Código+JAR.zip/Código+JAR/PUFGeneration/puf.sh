#!/bin/bash

python /home/pi/Documents/ReadV2/ReadSRAM/SerialNumber.py
python /home/pi/Documents/ReadV2/ReadSRAM/puf.py
